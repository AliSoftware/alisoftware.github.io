
import Foundation

struct RegEx {
  let expression: NSRegularExpression

  enum Capture {
    case no
    case index
    case name(String)
  }
  let captures: [(Capture, String)]
}

extension RegEx: ExpressibleByStringLiteral {
  init(stringLiteral: String) {
    self.expression = try! NSRegularExpression(pattern: stringLiteral, options: [])
    self.captures = []
  }
}

extension RegEx: CustomStringConvertible {
  var description: String {
    return self.expression.pattern
  }
}

extension RegEx.Capture: CustomStringConvertible {
  var description: String {
    switch self {
    case .no: return "?:"
    case .index: return ""
    case .name(let name): return "?<\(name)>"
    }
  }
}

extension RegEx: ExpressibleByStringInterpolation {
  init(stringInterpolation: StringInterpolation) {
    self.expression = try! NSRegularExpression(pattern: stringInterpolation.pattern, options: stringInterpolation.options)
    self.captures = stringInterpolation.captures
  }

  struct StringInterpolation: StringInterpolationProtocol {
    var pattern: String
    var options: NSRegularExpression.Options = []
    var captures: [(Capture, String)] = []

    init(literalCapacity: Int, interpolationCount: Int) {
      pattern = ""
    }

    mutating func appendLiteral(_ literal: String) {
      pattern += NSRegularExpression.escapedPattern(for: literal)
    }

    mutating func appendInterpolation(either list: [String], capturing: Capture = .index) {
      let esc = list.map(NSRegularExpression.escapedPattern(for:)).joined(separator: "|")
      pattern += "(\(capturing)\(esc))"
      captures.append((capturing, esc))
    }

    mutating func appendInterpolation(maybe string: String, capturing: Capture = .index) {
      let esc = NSRegularExpression.escapedPattern(for: string)
      pattern += "(\(capturing)\(esc))?"
      captures.append((capturing, esc))
    }

    mutating func appendInterpolation(zeroOrMore string: String, capturing: Capture = .index) {
      let esc = NSRegularExpression.escapedPattern(for: string)
      pattern += "(\(capturing)\(esc))*"
      captures.append((capturing, esc))
    }

    mutating func appendInterpolation(oneOrMore string: String, capturing: Capture = .index) {
      let esc = NSRegularExpression.escapedPattern(for: string)
      pattern += "(\(capturing)\(esc))+"
      captures.append((capturing, esc))
    }

    mutating func appendInterpolation(oneOf chars: String) {
      appendInterpolation(oneOf: Set(chars))
    }

    mutating func appendInterpolation(oneOf chars: Set<Character>) {
      // TODO: If "-" is in set, put it last
      // TODO: If "]" is in set, put it first
      pattern += "[\(chars)]"
    }

    mutating func appendInterpolation(capture: Capture = .index, _ content: RegEx) {
      let text = content.expression.pattern
      pattern += "(\(capture)\(text))"
      captures.append((capture, text))
    }
  }
}

let re: RegEx = "This \(either: ["word", "letter"], capturing: .name("type")) is \(zeroOrMore: "very ")long. \(capture: .name("rest"), "This is \(maybe: "quite ")cool, right?")"
print(re) // This (?<type>word|letter) is (very )*long\. (?<rest>This is (quite )?cool, right\?)

