
import Foundation

//: # Declare RegEx type
//: And make it conform to ExpressibleByStringInterpolation

struct RegEx {
  let expression: NSRegularExpression

  enum Capture {
    case no
    case index
    case name(String)
  }
  let captures: [(Capture, String)]
}

extension RegEx: ExpressibleByStringLiteral {
  init(stringLiteral: String) {
    self.expression = try! NSRegularExpression(pattern: stringLiteral, options: [])
    self.captures = []
  }
}

extension RegEx: CustomStringConvertible {
  var description: String {
    return self.expression.pattern
  }
}

extension RegEx.Capture: CustomStringConvertible {
  var description: String {
    switch self {
    case .no: return "?:"
    case .index: return ""
    case .name(let name): return "?<\(name)>"
    }
  }
}

extension RegEx: ExpressibleByStringInterpolation {
  init(stringInterpolation: StringInterpolation) {
    self.expression = try! NSRegularExpression(pattern: stringInterpolation.pattern, options: stringInterpolation.options)
    self.captures = stringInterpolation.captures
  }

  struct StringInterpolation: StringInterpolationProtocol {
    var pattern: String
    var options: NSRegularExpression.Options = []
    var captures: [(Capture, String)] = []

    init(literalCapacity: Int, interpolationCount: Int) {
      pattern = ""
    }

    mutating func appendLiteral(_ literal: String) {
      pattern += NSRegularExpression.escapedPattern(for: literal)
    }

    mutating func appendInterpolation(either list: [String], capturing: Capture = .index) {
      let esc = list.map(NSRegularExpression.escapedPattern(for:)).joined(separator: "|")
      pattern += "(\(capturing)\(esc))"
      captures.append((capturing, esc))
    }

    mutating func appendInterpolation(maybe string: String, capturing: Capture = .index) {
      let esc = NSRegularExpression.escapedPattern(for: string)
      pattern += "(\(capturing)\(esc))?"
      captures.append((capturing, esc))
    }

    mutating func appendInterpolation(zeroOrMore string: String, capturing: Capture = .index) {
      let esc = NSRegularExpression.escapedPattern(for: string)
      pattern += "(\(capturing)\(esc))*"
      captures.append((capturing, esc))
    }

    mutating func appendInterpolation(oneOrMore string: String, capturing: Capture = .index) {
      let esc = NSRegularExpression.escapedPattern(for: string)
      pattern += "(\(capturing)\(esc))+"
      captures.append((capturing, esc))
    }

    mutating func appendInterpolation(oneOf chars: String) {
      appendInterpolation(oneOf: Set(chars))
    }

    mutating func appendInterpolation(oneOf chars: Set<Character>) {
      // TODO: If "-" is in set, put it last
      // TODO: If "]" is in set, put it first
      pattern += "[\(chars)]"
    }

    mutating func appendInterpolation(capture: Capture = .index, _ content: RegEx) {
      let text = content.expression.pattern
      pattern += "(\(capture)\(text))"
      captures.append((capture, text))
    }
  }
}




//: ## Demo: Build the RegEx

let re: RegEx = """
    This \(either: ["word", "book"], capturing: .name("type")) is \(zeroOrMore: "very ", capturing: .no)long. \
    \(capture: .name("coolness"), "This is \(maybe: "quite ")cool\(maybe: ", right?")")
    """
print("RegEx:", re) // This (?<type>word|book) is (?:very )*long\. (?<coolness>This is (quite )?cool(, right\?)?)

print("Captures:", re.captures)
print("---")






//: # Finding Matches

//: ## Helper to list matches
//: In a Swifty way, allowing manipulation of Swift Ranges instead of NSRange

extension RegEx {
    struct Match {
        let result: NSTextCheckingResult
        let ranges: [Range<String.Index>?]
        var range: Range<String.Index> { return ranges[0]! }
        let namedCaptures: [String: Range<String.Index>?]

        init(result: NSTextCheckingResult, in string: String, captures: [Capture]) {
            self.result = result
            self.ranges = (0..<result.numberOfRanges).map { idx in
                let nsrange = result.range(at: idx)
                return nsrange.location == NSNotFound ? nil : Range(nsrange, in: string)!
            }
            self.namedCaptures = captures.reduce(into: [:]) { acc, cap in
                if case Capture.name(let name) = cap {
                    let nsrange = result.range(withName: name)
                    acc[name] = nsrange.location == NSNotFound ? nil : Range(nsrange, in: string)!
                }
            }
        }
    }

    func matches(in string: String, options: NSRegularExpression.MatchingOptions = []) -> [Match] {
        let range = NSRange(string.startIndex..<string.endIndex, in: string)
        return self.expression.matches(in: string, options: options, range: range)
            .map { Match(result: $0, in: string, captures: self.captures.map { $0.0 } ) }
    }
}




//: ## Demo: Using RegEx to match some string

let text = """
    Hello :) Do you know about supercalifragilisticexpialidocious? This word is long. This is quite cool!
    What about Moby Dick? This book is very very long. This is cool, right? Everybody loves it.
    """

let matches = re.matches(in: text)

// Print all matches, with all capture groups in each matches
matches.enumerated().forEach { (index: Int, match: RegEx.Match) in
    print("* Captures found in match #\(index):")
    match.ranges.enumerated().forEach {
        if let range = $0.element {
            print("   - #\($0.offset): \(text[range])")
        } else {
            print("   - #\($0.offset): no match")
        }
    }
    match.namedCaptures.forEach { (name: String, range: Range<String.Index>?) in
        if let range = range {
            print("   - '\(name)': \(text[range])")
        } else {
            print("   - '\(name)': no match")
        }
    }
}

