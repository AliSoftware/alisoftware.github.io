import Foundation
import XCPlayground
// Tell the playground to run indefinitely so it can at least let delayed code be executed
// after we reached the end of the code
XCPlaygroundPage.currentPage.needsIndefiniteExecution = true


//: # Closure Capture Semantics, Part 1

/*:
 - Note:
   To test th following examples, I recommend to only uncomment one `demoX()` call at a time,
   and re-comment it to un-comment the next one, since these demos use asynchronous delays
   and executing all the demos as once would be confusing.
 - Note:
   Every time you uncomment a call to one of the `demoX()` function, it might help Xcode to
   click the Stop then Play button at the bottom of Xcode Playground to recompile & relaunch it.
 */

//: ## Introduction
//: Defining some class and function to use in the demos

class Pokemon: CustomDebugStringConvertible {
  let name: String
  init(name: String) {
    self.name = name
  }
  var debugDescription: String { return "<Pokemon \(name)>" }
  deinit { print("\(self) escaped!") }
}



func delay(seconds: NSTimeInterval, closure: ()->()) {
  let time = dispatch_time(DISPATCH_TIME_NOW, Int64(seconds * Double(NSEC_PER_SEC)))
  dispatch_after(time, dispatch_get_main_queue()) {
    print("🕑")
    closure()
  }
}



//: ## Demo 1

func demo1() {
  let pokemon = Pokemon(name: "Mewtwo")
  print("before closure: \(pokemon)")
  delay(1) {
    print("inside closure: \(pokemon)")
  }
  print("bye")
}

demo1()




//: ## Demo 2

func demo2() {
  var pokemon = Pokemon(name: "Pikachu")
  print("before closure: \(pokemon)")
  delay(1) {
    print("inside closure: \(pokemon)")
  }
  pokemon = Pokemon(name: "Mewtwo")
  print("after closure: \(pokemon)")
}

//demo2()





//: ## Demo 3

func demo3() {
  var value = 42
  print("before closure: \(value)")
  delay(1) {
    print("inside closure: \(value)")
  }
  value = 1337
  print("after closure: \(value)")
}

//demo3()




//: ## Demo 4

func demo4() {
  var value = 42
  print("before closure: \(value)")
  delay(1) {
    print("inside closure 1, before change: \(value)")
    value = 1337
    print("inside closure 1, after change: \(value)")
  }
  delay(2) {
    print("inside closure 2: \(value)")
  }
}

//demo4()




//: ## Demo 5

func demo5() {
  var value = 42
  print("before closure: \(value)")
  delay(1) { [constValue = value] in
    print("inside closure: \(constValue)")
  }
  value = 1337
  print("after closure: \(value)")
}

//demo5()






//: ## Demo 6

func demo6() {
  var pokemon = Pokemon(name: "Pikachu")
  print("before closure: \(pokemon)")
  delay(1) { [pokemonCopy = pokemon] in
    print("inside closure: \(pokemonCopy)")
  }
  pokemon = Pokemon(name: "Mewtwo")
  print("after closure: \(pokemon)")
}

//demo6()





//: ## Demo 7: Mixing it all

func demo7() {
  var pokemon = Pokemon(name: "Mew")
  print("➡️ Initial pokemon is \(pokemon)")

  delay(1) { [capturedPokemon = pokemon] in
    print("closure 1 — pokemon captured at creation time: \(capturedPokemon)")
    print("closure 1 — variable evaluated at execution time: \(pokemon)")
    pokemon = Pokemon(name: "Pikachu")
    print("closure 1 - pokemon has been now set to \(pokemon)")
  }

  pokemon = Pokemon(name: "Mewtwo")
  print("🔄 pokemon changed to \(pokemon)")

  delay(2) { [capturedPokemon = pokemon] in
    print("closure 2 — pokemon captured at creation time: \(capturedPokemon)")
    print("closure 2 — variable evaluated at execution time: \(pokemon)")
    pokemon = Pokemon(name: "Charizard")
    print("closure 2 - value has been now set to \(pokemon)")
  }
}

//demo7()






//: ### The End

// End the playground infinite execution after 4 seconds to avoid using useless CPU
delay(4) {
  print("--- THE END ---")
  XCPlaygroundPage.currentPage.finishExecution()
}
