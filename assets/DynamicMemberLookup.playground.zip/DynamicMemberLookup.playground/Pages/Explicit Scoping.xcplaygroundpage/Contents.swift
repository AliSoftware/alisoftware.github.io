import UIKit




struct Pet {
  let name: String
  let age: Int
}

let d: [String: Any] = [
  "name": "Olivier",
  "address": [
    "street": "Swift Street",
    "number": 1337,
    "city": "PlaygroundVille"
  ],
  "flatmates": [
    "pets": [
      Pet(name: "Rex", age: 6),
      Pet(name: "Felix", age: 3)
    ]
  ]
]

// ".dynamicLookup" enters a full scope where everything is dynamically looked-up
let street: String? = d.dynamicLookup { $0.address?.street }
// '^' operator allows only the next member lookup to be dynamic.
// '^' has to be repeated if we want to chain multiple dynamic lookups
let x = d^.address

let sameStreet: String? = d^.address?^.street

let pets = d^.flatmates?^.pets as? [Pet]
let rex = pets?.first?.name

let felix = d.dynamicLookup { $0.flatmates?.pets?[1] } as Pet?
let felixName = felix?.name

let notFoundKey: String? = d^.address^.zipcode
let notFoundKey2: String? = d^.car^.licensePlate



let j: [String: Any] = [
  "comment": "Being able to tell the difference at call site is explicitly is nicer",
  "count": 42,
  "count2": 1337
]
j.count // checked at compile time
j^.count // dynamic lookup

//j.cuont // compile-time error
j^.cuont // dynamic lookup, but key not found. Returns nil.

let j2: [String: Any] = [
  "name": "Olivier",
  "address": [
    "street": "Swift Street",
    "number": 1337,
    "city": "PlaygroundVille"
  ]
]


j2^.name // Returns "Olivier"
j2^.address^.street // Returns "Swift Street"
// The line above is actually equivalent to, but way nicer, than the one below:
(j2["address"] as? [String: Any])?["street"]
j2^.address^.zipcode // Returns nil, as there's no zipcode

// j2^.address?.zipcode // Does not compile (ambiguous return type of j2^.address, the compiler cannot determine T)
let addr: [String: Any]? = j2^.address
addr^.street // Returns "Swift Street"
addr?["street"] // same thing, really, but arguably less nice

addr?.count // compile-time checked expression. Returns 3

let street2: String? = d.dynamicLookup { $0.address?.street }
