//: [Previous](@previous)

// Extending the from [SE-0195](https://github.com/apple/swift-evolution/blob/master/proposals/0195-dynamic-member-lookup.md)

@dynamicMemberLookup
enum JSON {
  case intValue(Int)
  case stringValue(String)
  case arrayValue(Array<JSON>)
  case dictionaryValue(Dictionary<String, JSON>)
  subscript(dynamicMember member: String) -> JSON? {
    if case .dictionaryValue(let dict) = self {
      return dict[member]
    }
    return nil
  }
  var count: Int {
    switch self {
    case .intValue, .stringValue: return 1
    case .arrayValue(let a): return a.count
    case .dictionaryValue(let d): return d.count
    }
  }
}



// Example JSON to work with

let j = JSON.dictionaryValue([
  "comment": .stringValue("Not being able to tell the difference at call site is confusing"),
  "count": .intValue(42),
  "count2": .intValue(1337)
  ])

// Show the issue: hard to know when this is solved dynamically vs at compile time
j.count
j.count2
j.cuont // And this will compile despite the typo (and return nil because no such key exists in the JSON)

//: [Next](@next)
