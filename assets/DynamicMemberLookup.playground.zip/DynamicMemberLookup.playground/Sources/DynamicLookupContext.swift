
@dynamicMemberLookup
public struct DynamicLookupContext {
  let value: Any

  public subscript(dynamicMember member: String) -> DynamicLookupContext? {
    let dict = value as? [String: Any]
    guard let value = dict?[member] else { return nil }
    return DynamicLookupContext(value: value)
  }
  public subscript(index: Int) -> DynamicLookupContext? {
    guard let array = value as? [Any] else { return nil }
    return DynamicLookupContext(value: array[index])
  }
}

public extension Dictionary where Key == String, Value: Any {
  func dynamicLookup<T>(execute: (DynamicLookupContext) -> DynamicLookupContext?) -> T? {
    return execute(DynamicLookupContext(value: self))?.value as? T
  }
}

